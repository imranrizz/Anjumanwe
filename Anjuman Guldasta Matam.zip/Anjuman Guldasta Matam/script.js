document.addEventListener('DOMContentLoaded', function() {
    // Function to show the specified chapter
    function showChapter(chapter) {
      const chapters = document.querySelectorAll('.his-Con');
      chapters.forEach(chap => chap.classList.remove('active'));
      document.getElementById(`chapter-${chapter}`).classList.add('active');
    }

    // Add click event listeners to the buttons
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
      button.addEventListener('click', function() {
        const chapter = this.getAttribute('data-chapter');
        showChapter(chapter);
      });
    });

    // Show chapter 1 by default
    showChapter(1);
  });